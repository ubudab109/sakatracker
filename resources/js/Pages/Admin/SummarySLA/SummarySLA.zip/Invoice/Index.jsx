import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import Table from './Partials/Table';
import ModifyButton from '@/Components/ModifyButton';
import { Head, Link } from '@inertiajs/react';
import { useState } from "react";

export default function Index(props) {
    const [selectedOption, setSelectedOption] = useState('Jalur 1'); // State untuk menyimpan opsi terpilih

    const handleSelectChange = (event) => {
        setSelectedOption(event.target.value); // Mengubah state saat opsi terpilih berubah
    };

    const dummyData = [
        {
            id: 1,
            nama_jalurOne: 'Bapak Appr 2',
            nama_jalurA: 'Bapak Prep 1',
            nama_jalurB: 'Accounting',
            onTime__jalurOne : 0,
            onTime__jalurA : 0,
            onTime__jalurB : 0,
            delayed__jalurOne : 0,
            delayed__jalurA : 0,
            delayed__jalurB : 0,
            achievement__jalurOne : 100,
            achievement__jalurA : 100,
            achievement__jalurB : 100,
        },
        {
            id: 2,
            nama_jalurOne: 'Bapak Prep 1',
            nama_jalurA: 'Bapak Appr 1',
            nama_jalurB: 'Legal',
            onTime__jalurOne : 0,
            onTime__jalurA : 0,
            onTime__jalurB : 0,
            delayed__jalurOne : 0,
            delayed__jalurA : 0,
            delayed__jalurB : 0,
            achievement__jalurOne : 100,
            achievement__jalurA : 100,
            achievement__jalurB : 100,
        },
            {
            id: 3,
            nama_jalurOne: 'Bapak Prep 1',
            nama_jalurA: 'Bapak Appr 2',
            nama_jalurB: 'Purchasing',
             onTime__jalurOne : 0,
            onTime__jalurA : 0,
            onTime__jalurB : 0,
            delayed__jalurOne : 0,
            delayed__jalurA : 0,
            delayed__jalurB : 0,
            achievement__jalurOne : 100,
            achievement__jalurA : 100,
            achievement__jalurB : 100,
        }
    ];

    return (
        <AuthenticatedLayout
            user={props.auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Summary SLA Invoice</h2>}
        >
            <Head title="Summary SLA Invoice" />

                        <div className="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 className="mb-sm-0 font-size-18">Summary SLA Invoice</h4>
            </div>

            {/* Dropdown Select */}
            <select value={selectedOption} onChange={handleSelectChange}>
                <option value="Jalur 1">Jalur 1</option>
                <option value="Jalur A">Jalur A</option>
                <option value="Jalur B">Jalur B</option>
            </select>

            <div className="pt-3">
                <div className="">
                    <div className="bg-white overflow-hidden shadow-lg sm:rounded-lg p-6">
                        <Table dummyData={dummyData} selectedOption={selectedOption} />
                    </div>
                </div>
            </div>

        </AuthenticatedLayout>
    );
}
