import React, { useEffect, useRef, useState } from 'react';
import 'datatables.net-dt/css/jquery.dataTables.min.css';
import $ from 'jquery';
import 'datatables.net';

export default function Table({ dummyData, selectedOption }) {
    const [showModal, setShowModal] = useState(false);
    const [itemToDelete, setItemToDelete] = useState(null);

    const tableRef = useRef(null);

useEffect(() => {
        // Menghancurkan DataTable yang ada jika ada
        if ($.fn.DataTable.isDataTable(tableRef.current)) {
            $(tableRef.current).DataTable().destroy();
        }

        // Inisialisasi DataTable yang baru
        $(tableRef.current).DataTable();
    }, [selectedOption]);

    return (
        <div className="pt-6">
            <div className="max-w-7xl mx-auto">
                <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg w-full overflow-x-auto">
                    <table ref={tableRef} className="w-full">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>On Time</th>
                                <th>Delayed</th>
                                <th>Achievement(%)</th>
                            </tr>
                        </thead>
                        <tbody>
                            {dummyData.map((item, index) => (
                                <tr className="border-t bg-gray-100 text-center" key={index}>
                                    <td className='border border-slate-600'>{item.id}</td>
                                    <td className={`border border-slate-600`}>{
                                        selectedOption === 'Jalur 1'
                                            ? item.nama_jalurOne
                                            : selectedOption === 'Jalur A'
                                                ? item.nama_jalurA
                                                : selectedOption === 'Jalur B'
                                                    ? item.nama_jalurB
                                                    : ''
                                    }</td>
                                    <td className={`border border-slate-600`}>{
                                        selectedOption === 'Jalur 1'
                                            ? item.onTime__jalurOne
                                            : selectedOption === 'Jalur A'
                                                ? item.onTime__jalurA
                                                : selectedOption === 'Jalur B'
                                                    ? item.onTime__jalurB
                                                    : ''
                                    }</td>
                                    <td className={`border border-slate-600`}>{
                                        selectedOption === 'Jalur 1'
                                            ? item.delayed__jalurOne
                                            : selectedOption === 'Jalur A'
                                                ? item.delayed__jalurA
                                                : selectedOption === 'Jalur B'
                                                    ? item.delayed__jalurB
                                                    : ''
                                    }</td>
                                    <td className={`border border-slate-600`}>{
                                        selectedOption === 'Jalur 1'
                                            ? item.achievement__jalurOne
                                            : selectedOption === 'Jalur A'
                                                ? item.achievement__jalurA
                                                : selectedOption === 'Jalur B'
                                                    ? item.achievement__jalurB
                                                    : ''
                                    }</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            {itemToDelete && (
                <ModalDelete
                    show={showModal}
                    onClose={() => setShowModal(false)}
                    item={itemToDelete}
                />
            )}
        </div>
    );
}
