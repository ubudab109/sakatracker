import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import Table from './Partials/Table';
import ModifyButton from '@/Components/ModifyButton';
import { Head, Link } from '@inertiajs/react';
import {useState} from "react";

export default function Index(props) {
const [selectedOption, setSelectedOption] = useState(''); // State untuk menyimpan opsi terpilih

const handleSelectChange = (event) => {
    setSelectedOption(event.target.value); // Mengubah state saat opsi terpilih berubah
};

const dummyData = [
    {   id: 1, 
        no_dokumen: 'DTF00010', 
        kode_vendor : '0234',
        status : 'Disetujui',
        tanggal_approve : '22-09-2023 16:56',
        document_stage : 'Dokumen Disetujui',
        tanggal_dibuat : '22-09-2023 16:23',
        total_sla : '1',
    },
];

    return (
        <AuthenticatedLayout
            user={props.auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Tax</h2>}
        >
            <Head title="SLA Monitoring Invoice" />

            <div className="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 className="mb-sm-0 font-size-18">SLA Monitoring Invoice</h4>
            </div>

            {/* Dropdown Select */}
                <select value={selectedOption} onChange={handleSelectChange}>
                    <option value="Jalur 1">Jalur 1</option>
                    <option value="Jalur A">Jalur A</option>
                    <option value="Jalur B">Jalur B</option>
                </select>

            <div className="pt-3">
                <div className="">
                    <div className="bg-white overflow-hidden shadow-lg sm:rounded-lg p-6">
                        <Table dummyData={dummyData} routeEdit="tax.edit" selectedOption={selectedOption} />
                    </div>
                </div>
            </div>

        </AuthenticatedLayout>
    );
}
