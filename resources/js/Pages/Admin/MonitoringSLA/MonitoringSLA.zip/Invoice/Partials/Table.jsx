import React, { useEffect, useRef, useState } from 'react';
import 'datatables.net-dt/css/jquery.dataTables.min.css';
import Dropdown from '@/Components/Dropdown';
import $ from 'jquery';
import 'datatables.net';
import { Edit, Trash, X, Check } from 'react-feather';

export default function Table({dummyData, selectedOption}) {
    const [showModal, setShowModal] = useState(false);
    const [itemToDelete, setItemToDelete] = useState(null);

    const tableRef = useRef(null);

    useEffect(() => {
        $(tableRef.current).DataTable();
    }, []);

    return (
        <div className="pt-6">
            <div className="max-w-7xl mx-auto">
                <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg w-full overflow-x-auto">
                    <table ref={tableRef} className="w-full">
                        <thead>
                            <tr>
                                <th>No Dokumen</th>
                                <th>Kode Vendor</th>
                                <th>Status</th>
                                <th>Tanggal Approve</th>
                                <th>Document Stage</th>
                                <th>Tanggal Dibuat</th>
                                {selectedOption === 'Jalur 1' && <th>Bapak Appr 2</th>}
                                {selectedOption === 'Jalur 1' && <th>Bapak Prep 1</th>}
                                {selectedOption === 'Jalur A' && <th>Bapak Prep 1</th>}
                                {selectedOption === 'Jalur A' && <th>Bapak Appr 1</th>}
                                {selectedOption === 'Jalur A' && <th>Bapak Appr 2</th>}
                                {selectedOption === 'Jalur B' && <th>Accounting</th>}
                                {selectedOption === 'Jalur B' && <th>Legal</th>}
                                {selectedOption === 'Jalur B' && <th>Purchasing</th>}
                                <th>Total SLA</th>
                            </tr>
                        </thead>
                        <tbody>
                            {dummyData.map((item, index) => (
                                <tr className="border-t bg-gray-100 text-center" key={index}>
                                    <td className='border border-slate-600'>{item.no_dokumen}</td>
                                    <td className='border border-slate-600'>{item.kode_vendor}</td>
                                    <td className='border border-slate-600'>{item.status}</td>
                                    <td className='border border-slate-600'>{item.tanggal_approve}</td>
                                    <td className='border border-slate-600'>{item.document_stage}</td>
                                    <td className='border border-slate-600'>{item.tanggal_dibuat}</td>
                                    {selectedOption === 'Jalur 1' && <td className={`border border-slate-600 ${item.bapak_Appr_dua >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>{item.bapak_Appr_dua}</td>}
                                    {selectedOption === 'Jalur 1' && <td className={`border border-slate-600 ${item.bapak_Prep_satu >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>{item.bapak_Prep_satu}</td>}
                                    {selectedOption === 'Jalur A' && <td className={`border border-slate-600 ${item.bapak_Prep_satu >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>{item.bapak_Prep_satu}</td>}
                                    {selectedOption === 'Jalur A' && <td className={`border border-slate-600 ${item.bapak_Appr_satu >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>{item.bapak_Appr_satu}</td>}
                                    {selectedOption === 'Jalur A' && <td className={`border border-slate-600 ${item.bapak_Appr_dua >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>{item.bapak_Appr_dua}</td>}
                                    {selectedOption === 'Jalur B' && <td className={`border border-slate-600 ${item.accounting >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>{item.accounting}</td>}
                                    {selectedOption === 'Jalur B' && <td className={`border border-slate-600 ${item.legal >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>{item.legal}</td>}
                                    {selectedOption === 'Jalur B' && <td className={`border border-slate-600 ${item.purchasing >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>{item.purchasing}</td>}
                                    <td className='border border-slate-600'>{item.total_sla}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            {itemToDelete && (
                <ModalDelete
                    show={showModal}
                    onClose={() => setShowModal(false)}
                    item={itemToDelete}
                />
            )}
        </div>
    );
}
