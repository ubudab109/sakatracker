import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import Table from './Partials/Table';
import ModifyButton from '@/Components/ModifyButton';
import { Head, Link } from '@inertiajs/react';
import React from "react";

export default function Index(props) {
const dummyData = [
    {   id: 1, 
        no_batch: 7, 
        status : 'Disetujui',
        tanggal_approve : '1-10-2023 09:11',
        document_stage : 'Dokumen Disetujui',
        tanggal_dibuat : '1-10-2023 08:58',
        finance_satu : '1',
        finance_dua : '2',
        accounting : '0',
        manager : '0',
        head_Manager : '0',
        director : '1',
        president_Director : '1',
        dIC : '1',
        total_sla : '6',
    },
];


    return (
        <AuthenticatedLayout
            user={props.auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Tax</h2>}
        >
            <Head title="SLA Monitoring Payment" />

            <div className="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 className="mb-sm-0 font-size-18">SLA Monitoring Payment</h4>
            </div>

            <div className="pt-3">
                <div className="">
                    <div className="bg-white overflow-hidden shadow-lg sm:rounded-lg p-6">
                        <Table dummyData={dummyData} routeEdit="tax.edit" />
                    </div>
                </div>
            </div>

        </AuthenticatedLayout>
    );
}
