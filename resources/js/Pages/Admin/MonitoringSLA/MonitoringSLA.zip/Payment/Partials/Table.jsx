import React, { useEffect, useRef, useState } from 'react';
import 'datatables.net-dt/css/jquery.dataTables.min.css';
import Dropdown from '@/Components/Dropdown';
import $ from 'jquery';
import 'datatables.net';
import { Edit, Trash, X, Check } from 'react-feather';

export default function Table({dummyData}) {
    const [showModal, setShowModal] = useState(false);
    const [itemToDelete, setItemToDelete] = useState(null);

    const tableRef = useRef(null);

    useEffect(() => {
        $(tableRef.current).DataTable();
    }, []);

    return (
        <div className="pt-6">
            <div className="max-w-7xl mx-auto">
                <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg w-full overflow-x-auto">
                    <table ref={tableRef} className="w-full">
                        <thead>
                            <tr>
                                <th>No Batch</th>
                                <th>Status</th>
                                <th>Tanggal Approve</th>
                                <th>Document Stage</th>
                                <th>Tanggal Dibuat</th>
                                <th>Finance 1</th>
                                <th>Finance 2</th>
                                <th>Accounting</th>
                                <th>Manager</th>
                                <th>Head of Manager</th>
                                <th>Director</th>
                                <th>President Director</th>
                                <th>Director in Charge / DIC</th>
                                <th>Total SLA</th>
                            </tr>
                        </thead>
                        <tbody>
                            {dummyData.map((item, index) => (
                                <tr className="border-t bg-gray-100 text-center" key={index}>
                                    <td className='border border-slate-600'>{item.no_batch}</td>
                                    <td className='border border-slate-600'>{item.status}</td>
                                    <td className='border border-slate-600'>{item.tanggal_approve}</td>
                                    <td className='border border-slate-600'>{item.document_stage}</td>
                                    <td className='border border-slate-600'>{item.tanggal_dibuat}</td>
                                    <td className={`border border-slate-600 ${item.finance_satu >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>
                                        {item.finance_satu}
                                    </td>
                                    <td className={`border border-slate-600 ${item.finance_dua >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>
                                        {item.finance_dua}
                                    </td>
                                    <td className={`border border-slate-600 ${item.accounting >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>
                                        {item.accounting}
                                    </td>
                                    <td className={`border border-slate-600 ${item.manager >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>
                                        {item.manager}
                                    </td>
                                    <td className={`border border-slate-600 ${item.head_Manager >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>
                                        {item.head_Manager}
                                    </td>
                                    <td className={`border border-slate-600 ${item.director >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>
                                        {item.director}
                                    </td>
                                    <td className={`border border-slate-600 ${item.president_Director >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>
                                        {item.president_Director}
                                    </td>
                                    <td className={`border border-slate-600 ${item.dIC >= 1 ? 'bg-red-400' : 'bg-green-300'}`}>
                                        {item.dIC}
                                    </td>
                                    <td className='border border-slate-600'>{item.total_sla}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            {itemToDelete && (
                <ModalDelete
                    show={showModal}
                    onClose={() => setShowModal(false)}
                    item={itemToDelete}
                />
            )}
        </div>
    );
}
